import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;



/**
 * Servlet implementation class date_update
 */
@WebServlet("/date_update")

public class date_update extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public date_update() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 try
		   {
			 
			 String prjname=request.getParameter("prjname");
				 int level1=0,level=0,seq=0;
				 int sno=0,cnt=0,cnt1=0;
				 Date d1,d2,d3,d4,d5,d6;
		     String myDriver = "org.gjt.mm.mysql.Driver";
		     String myUrl = "jdbc:mysql://localhost:3306/strutsdb";
		     Class.forName(myDriver);
		     Connection conn = DriverManager.getConnection(myUrl, "root", "password123");
		     String query = "select * from archive_exec where projects='"+prjname+"' order by seq_num";
		     Statement st = conn.createStatement();
		     ResultSet rs = st.executeQuery(query);
		     SimpleDateFormat fmt = new SimpleDateFormat("MM/dd/yyyy");
		     //DateFormat d3 = new SimpleDateFormat("mm/dd/yyyy");
		     ArrayList<Integer> seq_num = new ArrayList<Integer>();
		     ArrayList<Integer> level_num = new ArrayList<Integer>();
		     ArrayList<String> task_name = new ArrayList<String>();
		     ArrayList<String> member_ass = new ArrayList<String>();
		    ArrayList<String> plan_startdate = new ArrayList<String>();
		     ArrayList<String> plan_enddate = new ArrayList<String>();
		     ArrayList<String> actual_startdate = new ArrayList<String>();
		     ArrayList<String> actual_enddate = new ArrayList<String>();
		     ArrayList<String> planned_hours = new ArrayList<String>();
		     ArrayList<String> actual_hours = new ArrayList<String>();
		     
		     ArrayList<Date> pln_st = new ArrayList<Date>();
		       ArrayList<Date> pln_ed = new ArrayList<Date>();
		       ArrayList<Date> act_st = new ArrayList<Date>();
		     String temp;
		     int i=0,index=0;
		     System.out.println("hello.. ");
		     while(rs.next())
		     {    	  
		  	  seq_num.add(rs.getInt(1));
		  	level_num.add(rs.getInt(2));
		  	task_name.add(rs.getString(3));
		  	member_ass.add(rs.getString(4));
		  	plan_startdate.add(rs.getString(7));
		  	plan_enddate.add(rs.getString(8));
		  	actual_startdate.add(rs.getString(5));
		  	actual_enddate.add(rs.getString(6));
		  	planned_hours.add(rs.getString(13));
		  	actual_hours.add(rs.getString(9));
		  	i++;
		     }
		     
		  String tasks_name=request.getParameter("name");
		  String sequence_no=request.getParameter("sequence_no");
		  String plan_start=request.getParameter("plan_start");
		  String plan_end=request.getParameter("plan_end");
		  String actual_start=request.getParameter("actual_start");
		  String planned_hrs=request.getParameter("plan_hrs");
		  String actual_hrs=request.getParameter("actual_hrs");
		  	
		  
		     for(int j=0;j<i;j++)
		     {
		  	   if (task_name.get(j).equals(tasks_name))
		  	   {
		  		   level=level_num.get(j);
		  		   seq=seq_num.get(j);
		  		   index=j;
		  		   level1=level;

		  		   plan_startdate.set(index,plan_start);
		  		 plan_enddate.set(index,plan_end);
		  		 actual_startdate.set(index,actual_start);
		  		 
		  		   for(int k=index-1;k>=0;k--)
		  		   {
		  			 for(int w=k;w>=0;w--)
		                {
		                           
		                           if (level_num.get(w)==level1-1 || level_num.get(w)==1)
		                                 break;
		                           else if (level_num.get(w)==level1)
		                           {
		                           	if(!plan_startdate.get(w).equals(""))
		                                      pln_st.add(fmt.parse(plan_startdate.get(w)));
		                           	if(!plan_enddate.get(w).equals(""))
		                                pln_ed.add(fmt.parse(plan_enddate.get(w)));
		                           	if(!actual_startdate.get(w).equals(""))
		                                act_st.add(fmt.parse(actual_startdate.get(w)));
		                                      continue;
		                                      
		                           }                          
		                }
		                          for(int w=k+1;w<200;w++)
		                {
		                        	  System.out.println(plan_startdate.get(w));
		                           if (level_num.get(w)==level1+1 || level_num.get(w)==1 || level_num.get(w)==level-1)
		                                  break;
		                           else if (level_num.get(w)==level1)
		                           {
		                           	if(!plan_startdate.get(w).equals(""))
		                                      pln_st.add(fmt.parse(plan_startdate.get(w)));
		                           	if(!plan_enddate.get(w).equals(""))
		                                pln_ed.add(fmt.parse(plan_enddate.get(w)));
		                           	if(!actual_startdate.get(w).equals(""))
		                                act_st.add(fmt.parse(actual_startdate.get(w)));
		                                      continue;
		                                      
		                           }
		                  
		               
		                }
		                         /* for(int oi=0;oi<6;oi++){
		                        	  String ww=fmt.format(pln_st.get(oi));
		                             System.out.println(ww);
		                          }*/
		                          Date pminDate = Collections.min(pln_st);
		                          String plnstart=fmt.format(pminDate);
		                          Date pmaxDate = Collections.max(pln_ed);
		                          String plnend=fmt.format(pmaxDate);
		                          Date aminDate = Collections.min(act_st);
		                          String actulstart=fmt.format(aminDate);
		                          System.out.println(plnstart);
				  		
		  			   if (level_num.get(k)==0)
		  			   {
		  				  System.out.println("level0.. ");
		  				   break;
		  			   }
		  			   else if (level_num.get(k)>=level1)
		  			   {
		  				   System.out.println("continue");
		  				   continue;
		  				   
		  			   }
		  			   else
		  			   {
		  				 	if(plan_startdate.get(k).equals(""))
		  					{
		  				 		plan_startdate.set(k,plan_start);
		  				 		//System.out.println("bala murugan");
		  					}
		  				 	else
		  				 	{
		  				 			plan_startdate.set(k,plnstart);
		  				 	}

		  				 		
		  				 	if(plan_enddate.get(k).equals(""))
		  				 	{
		  				 		plan_enddate.set(k,plan_end);
		  				 	}
		  				 	else
		  				 	{
		  				 		plan_enddate.set(k,plnend);
		  				 	}
	  				     		if(actual_startdate.get(k).equals(""))
	  				     		{
	  				     			actual_startdate.set(k,actual_start);
	  				     		}
	  				     		else
	  				     		{
	  				     				actual_startdate.set(k,actulstart);
	  				     		}
	  				     		if(planned_hours.get(k).equals("")||actual_hours.get(k).equals(""))
	  				     		{
	  				     			planned_hours.set(k,planned_hrs);
	  				     			actual_hours.set(k,actual_hrs);
	  				     		}
	  				     		else
	  				     		{
	  				     			if(planned_hours.get(index).equals("")||actual_hours.get(index).equals(""))
	  				     			{
	  				     				planned_hours.set(k,Integer.toString(Integer.parseInt(planned_hrs)+Integer.parseInt(planned_hours.get(k))));
		  				  				actual_hours.set(k,String.valueOf((Integer.parseInt(actual_hrs)+Integer.parseInt(actual_hours.get(k)))));
	  				     			}
	  				     			else
	  				     			{
	  				     		 planned_hours.set(k,Integer.toString(Integer.parseInt(planned_hrs)+(Integer.parseInt(planned_hours.get(k))-Integer.parseInt(planned_hours.get(index)))));
	  				  				actual_hours.set(k,String.valueOf((Integer.parseInt(actual_hrs)+(Integer.parseInt(actual_hours.get(k))-Integer.parseInt(actual_hours.get(index))))));
	  				     			}}
			  				   level1=level1-1;
		  		 			   }

		  		   }
		  		 planned_hours.set(index,planned_hrs);
			  		actual_hours.set(index,actual_hrs);
		  	   }
		  
		     }
		     
		    

	   for(int n=0;n<i;n++)
			   {
			 //  System.out.println(seq_num.get(n)+"  "+level_num.get(n)+"  "+task_name.get(n)+"  "+plan_startdate.get(n)+" "+plan_enddate.get(n)+" "+actual_startdate.get(n));
			 
		    	 st.executeUpdate("update archive_exec set act_srt_date='"+actual_startdate.get(n)+"',pln_srt_date='"+plan_startdate.get(n)+"',pln_end_date='"+plan_enddate.get(n)+"',planned_hrs='"+planned_hours.get(n)+"',hours='"+actual_hours.get(n)+"'where seq_num='"+seq_num.get(n)+"' and projects='"+prjname+"'");
 // System.out.println("update archive_exec set act_srt_date='"+actual_startdate.get(n)+"',pln_srt_date='"+plan_startdate.get(n)+"',pln_end_date='"+plan_enddate.get(n)+"',planned_hrs='"+planned_hours.get(n)+"',hours='"+actual_hours.get(n)+"'where seq_num='"+seq_num.get(n)+"'");
  
			   }

		   }
		   catch (Exception e)
		   {
		   	 
		     System.err.println("Got an exception!");
		     System.err.println(e.getMessage());
		   }
		 response.sendRedirect("archive_exec_samp.jsp");

	}

}
