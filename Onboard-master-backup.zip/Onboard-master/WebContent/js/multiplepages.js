window.x;
function setID(mid)
{
	window.x=mid;
window.alert("set "+window.x);
window.location.href="grid.jsp";
}

function getID()
{
	 window.alert("get "+window.x);
return window.x;
}



