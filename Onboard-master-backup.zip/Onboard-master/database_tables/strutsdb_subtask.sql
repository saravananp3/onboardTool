-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: strutsdb
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `subtask`
--

DROP TABLE IF EXISTS `subtask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subtask` (
  `taskid` varchar(255) DEFAULT NULL,
  `subtaskid` varchar(255) DEFAULT NULL,
  `subtask` varchar(255) DEFAULT NULL,
  `mem_ass` varchar(255) DEFAULT NULL,
  `act_srt_dat` varchar(255) DEFAULT NULL,
  `act_end_dat` varchar(255) DEFAULT NULL,
  `pln_srt_dat` varchar(255) DEFAULT NULL,
  `pln_end_dat` varchar(255) DEFAULT NULL,
  `progress` varchar(255) DEFAULT NULL,
  `hrs` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subtask`
--

LOCK TABLES `subtask` WRITE;
/*!40000 ALTER TABLE `subtask` DISABLE KEYS */;
INSERT INTO `subtask` VALUES ('TN-10008','ST-10009','Develop and Approve Business Case',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10008','ST-10010','Request Project in GPS with Assigned Project',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10008','ST-10011','Assign PM and Project Owner',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10008','ST-10012','Assign Priority and Project Risk Score',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10008','ST-10013','Gate1 Approval to Plan',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10009','ST-10014','Onboarding ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10009','ST-10015','Project Kickoff',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10009','ST-10016','Project Plan',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10009','ST-10017','Process and Procedure definition',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10009','ST-10018','Finalize Governance Structure',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10009','ST-10019','Communication Plan',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10009','ST-10020','RACI',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10009','ST-10021','RAID Log',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10010','ST-10022','Application1 Name',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10011','ST-10029','Hypercare Support',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10011','ST-10030','Exit criteria meeting and Retirement communication',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10011','ST-10031','Stakeholder communication',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10011','ST-10032','Lessons learned',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10011','ST-10033','Project close check list',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10011','ST-10034','Final finances and invoices',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10011','ST-10035','Customer satisfaction survey',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10008','ST-10003','rr',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('TN-10010','ST-10000','samp',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `subtask` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-09 17:54:59
